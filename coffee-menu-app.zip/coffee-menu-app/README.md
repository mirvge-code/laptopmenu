# ☕ Электронное меню кофейни

## Описание
Полнофункциональное электронное меню для Android-планшета.

### Возможности:
- 👁 **Режим просмотра** — гость видит красивое меню
- ✏️ **Режим редактирования** — защищён PIN-кодом (по умолчанию: 1234)
- 📷 **Фотографии** блюд — загружаются прямо с устройства
- 💰 **Цены и описания** — редактируются в удобном интерфейсе
- 📂 **Категории** — настраиваются по желанию
- 💾 **Автосохранение** — данные хранятся в памяти устройства
- 📴 **Офлайн-режим** — работает без интернета (PWA)

---

## Вариант 1: Установить как PWA (БЫСТРО — 2 минуты)

1. Откройте браузер Chrome на Android-планшете
2. Откройте файл `index.html` или разместите на сервере
3. Нажмите «⋮» → «Добавить на главный экран»
4. Приложение появится как иконка — работает как полноценный APK!

> **Рекомендуется**: Загрузите файлы на бесплатный хостинг (Netlify, GitHub Pages)
> и откройте ссылку на планшете.

---

## Вариант 2: Собрать APK через Android Studio

### Шаг 1 — Установить Android Studio
Скачайте с https://developer.android.com/studio

### Шаг 2 — Создать новый проект
```
New Project → Empty Activity
Package name: com.coffeemenu.app
Min SDK: API 21 (Android 5.0)
```

### Шаг 3 — Скопировать файлы меню
Скопируйте все файлы (index.html, manifest.json, sw.js, иконки)
в папку: `app/src/main/assets/`

### Шаг 4 — Заменить MainActivity.java
```java
package com.coffeemenu.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Полноэкранный режим
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        
        webView = new WebView(this);
        setContentView(webView);
        
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);  // localStorage
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            // Для доступа к камере и файлам (фотографии блюд)
        });
        
        webView.loadUrl("file:///android_asset/index.html");
    }
    
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        }
        // Не закрываем приложение по Back
    }
}
```

### Шаг 5 — AndroidManifest.xml
Добавьте разрешения:
```xml
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>

<application
    android:theme="@android:style/Theme.NoTitleBar.Fullscreen"
    ...>
    <activity
        android:name=".MainActivity"
        android:screenOrientation="landscape"
        android:configChanges="orientation|keyboardHidden|screenSize"
        ...>
```

### Шаг 6 — Собрать APK
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```
APK будет в: `app/build/outputs/apk/debug/app-debug.apk`

---

## Вариант 3: Через Cordova CLI (5 минут)

```bash
# Установить Cordova
npm install -g cordova

# Создать проект
cordova create CoffeeMenu com.coffeemenu.app CoffeeMenu
cd CoffeeMenu

# Скопировать файлы в www/
cp /path/to/index.html www/
cp /path/to/sw.js www/
cp /path/to/manifest.json www/

# Добавить Android
cordova platform add android

# Собрать APK
cordova build android

# APK: platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

---

## Структура файлов
```
coffee-menu-app/
├── index.html      ← Главное приложение (всё в одном файле)
├── manifest.json   ← PWA манифест
├── sw.js           ← Service Worker (офлайн)
├── icon-192.png    ← Иконка приложения
└── icon-512.png    ← Иконка приложения (большая)
```

---

## PIN-код по умолчанию: **1234**
Изменить можно в разделе «Настройки» (режим редактирования → ⚙️)
